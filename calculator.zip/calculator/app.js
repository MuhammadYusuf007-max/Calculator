function calculate(operation) {
    let num1 = document.getElementById('num1').value;
    let num2 = document.getElementById('num2').value;
    let result;
    if (operation === 'add') {
        result = num1 + num2;
    } else if (operation === 'sub') {
        result = num1 - num2;
    } else if (operation === 'mul') {
        result = num1 * num2;
    } else if (operation === 'div') {
        result = parseFloat(num1 / num2);
    } else {
        document.getElementById('result').textContent = 'Son kiritishda xatoga yol qoydiz';
        return;
    }

    document.getElementById('result').textContent = `Javob: ${result}`;
}
